# Project 5 — Type-C Command-Path Defense in a Mininet SCADA Testbed

**Course:** ELE 420/520 Spring 2026 · **Author:** Sungyoun Seo

This submission implements and evaluates a relay-side, two-tier
pre-execution check that defends a smart-grid SCADA network against
**Type-C command-path attacks** (Lin et al., HotSoS 2016) injected by a
man-in-the-middle data aggregator. All artifacts (source, experiments,
analysis, results, LaTeX report) are in this directory; the compiled PDF
is provided alongside the code.

---

## 1. Layout

```
submission/
├── README.md                       (this file)
├── requirements.txt                NumPy + Matplotlib for tier-2 + plots
│
├── build_net.py                    Mininet topology (interactive xterm version)
├── control_center.py               cc — sends polls + DNP3m control commands
├── data_aggregator.py              da — MitM injection point (FDIA + Type-C)
├── relay1.py … relay4.py           4 protection-relay processes
├── relay_common.py                 ★ Tier-1 + Tier-2 defense logic (handle_message)
├── physics_model.py                ★ DC consequence model (H, W, severity)
├── util.py                         DNP3m pack / unpack helpers
├── calculate_fdia.m                MATLAB reference (H, W, z constants)
│
├── run_test.py                     Single-run Mininet harness (one mode/profile)
├── run_experiment_matrix.py        Full mode × profile × tier × trial sweep
├── run_stealthy_mininet.py         ★ Stealthy in-band attack ablation (36 runs)
├── stealthy_simulation.py          Direct-call sanity check (no Mininet)
│
├── analyze_results.py              Parses raw logs → summary CSVs
├── plot_results.py                 Original (legacy) plot generator
│
├── results/
│   ├── *.csv                       Aggregate metrics (summary, confusion, ablation)
│   ├── raw/                        164 Mininet logs from the matrix sweep
│   └── stealthy_raw/               36 Mininet logs from the stealthy ablation
│
└── report/
    ├── report.tex                  IEEE conference 2-column source
    ├── references.bib              14 BibTeX entries
    └── figures/
        ├── make_plots.py           SciencePlots IEEE-style figure generator
        └── fig_*.{pdf,png,svg}     6 publication figures
```

★ = files containing the contributed defense logic.

---

## 2. What the code does

| Component | Role |
|---|---|
| `data_aggregator.py` | Acts as MitM. With `PROJECT5_TYPE_C=1` it rewrites every forwarded control setpoint to `PROJECT5_MALICIOUS_SP` (default 8.0 pu). With `PROJECT5_FDIA=1` it overwrites poll responses with a Liu-style FDIA mapping. |
| `relay_common.handle_message()` | Tier-1 nominal-band check (Eq. 1 of the report) followed by Tier-2 linearized DC consequence score (Eqs. 2–3). Logs structured `PROJECT5,RELAY_CONTROL` lines for every decision. |
| `physics_model.tier2_severity()` | Computes `‖G·Δz‖∞` where `G = (HᵀWH)⁻¹HᵀW`. Gain matrix is cached at startup. |
| `run_stealthy_mininet.py` | Sweeps three attacker setpoints (benign 1.62 pu, **stealthy 2.5 pu**, gross 8.0 pu) × four tier configurations × three trials through the full Mininet stack. |

---

## 3. Reproducing the results

### Prerequisites
- **System Python 3** with Mininet installed (Open vSwitch + Mininet packages). Run experiment scripts as root.
- **Plot venv**: a separate Python venv with `numpy`, `matplotlib`, `scienceplots` is required only for `report/figures/make_plots.py`. Ours lives at `~/workspace/venv`.
- LaTeX (Overleaf or local TeX Live with `IEEEtran`, `tikz`, `listings`) for the report.

```bash
pip install -r requirements.txt          # numpy, matplotlib (for the relay process)
```

### A. Full Mininet matrix (Section IV-A of the report)
164 runs covering 4 modes × 3 profiles × 4 tier configurations × 3 trials.

```bash
sudo python3 run_experiment_matrix.py \
        --trials 3 --rounds 2 --sudo --skip-existing
python3 analyze_results.py
```
Outputs: `results/summary.csv`, `summary_by_mode.csv`, `summary_by_combo.csv`,
`confusion_table.csv`, `events.csv`, `ablation_delta.csv`.

### B. Stealthy in-band attack ablation (Section IV-B, the key result)
36 Mininet runs that demonstrate Tier-1 alone misses the in-band rewrite.

```bash
sudo python3 run_stealthy_mininet.py --trials 3
```
Output: `results/stealthy_mininet.csv` and per-run logs under `results/stealthy_raw/`.

### C. Regenerate the paper figures
Use the plot venv (system python typically lacks SciencePlots):

```bash
~/workspace/venv/bin/python report/figures/make_plots.py
```
Generates 4 publication figures in PDF/PNG/SVG. The two TikZ figures
(network topology, decision flow) are inline in `report.tex`.

### D. Compile the report
Upload `report/` to Overleaf and compile with **pdfLaTeX + BibTeX**, or
run locally:
```bash
cd report
pdflatex report.tex && bibtex report && pdflatex report && pdflatex report
```

### Single-run smoke tests
```bash
sudo python3 run_test.py                        # baseline poll + benign control
sudo PROJECT5_TYPE_C=1 python3 run_test.py      # gross Type-C attack (rejected)
sudo PROJECT5_TYPE_C=1 PROJECT5_MALICIOUS_SP=2.5 \
     python3 run_test.py --no-tier2             # stealthy attack, T1 only → ACCEPTED (miss)
sudo PROJECT5_TYPE_C=1 PROJECT5_MALICIOUS_SP=2.5 \
     python3 run_test.py                        # stealthy attack, T1+T2 → REJECTED
```

---

## 4. Environment-variable reference

| Variable | Default | Effect |
|---|---|---|
| `PROJECT5_FDIA` | `1` | Aggregator overwrites poll measurements. |
| `PROJECT5_TYPE_C` | `0` | Aggregator rewrites forwarded control setpoint. |
| `PROJECT5_MALICIOUS_SP` | `8.0` | Value used for the Type-C rewrite. Set to `2.5` for the stealthy in-band attack. |
| `PROJECT5_TIER1` | `1` | Enable tier-1 nominal-band check at the relay. |
| `PROJECT5_TIER2` | `1` | Enable tier-2 DC consequence score at the relay. |
| `PROJECT5_LOG_FILE` | unset | If set, every relay/aggregator process appends structured lines here. |
| `PROJECT5_MODE` | `default` | Tag included in `PROJECT5,CONFIG` log line. |

---

## 5. Headline results

- **Full Mininet matrix**: baseline ≡ fdia_only (85.4% accept), typec_only ≡ combined (22% accept). FDIA on the read path does **not** affect the write-path defense.
- **Confusion table** (328 paired events): 140 benign forwarded · 24 benign blocked · 36 attack forwarded · 128 attack blocked → policy accuracy 0.817. All misses and false blocks come from cells with deliberately disabled tiers.
- **Stealthy ablation (36 Mininet runs)**: when the MitM rewrites the operator's command to an in-band 2.5 pu, **`T1 only` lets the attack through (3/3 trials)**, while every configuration containing tier-2 rejects it (3/3 trials). Tier-1 on its own is insufficient against a sophisticated attacker.
- **Latency**: 0.05 ms tier-1 fast-reject, 0.32–0.45 ms tier-2 evaluation under Mininet — well below typical SCADA polling intervals.

---

## 6. References

The report cites 14 sources (see `report/references.bib`); the most directly relevant are:

- Liu, Ning, Reiter, *False Data Injection Attacks against State Estimation in Electric Power Grids*, ACM CCS 2009.
- Lin, Alemzadeh, Chen, Kalbarczyk, Iyer, *Safety-Critical Cyber-Physical Attacks: Analysis, Detection, and Mitigation*, HotSoS 2016.
- Lantz, Heller, McKeown, *A Network in a Laptop*, HotNets 2010 (Mininet).
- Yang et al., *Multiattribute SCADA-Specific Intrusion Detection System for Power Networks*, IEEE Trans. Power Delivery 2014.
